package com.waqtuka.app;

import android.app.*;
import android.content.*;
import android.os.*;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class UsageMonitorService extends Service {
    static final String CH_SVC = "svc", CH_ALERT = "alert";
    private final Handler h = new Handler(Looper.getMainLooper());
    private SharedPreferences st;
    private long contStart = 0, offAt = 0;
    private int lastCont = 0;

    private final BroadcastReceiver screen = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            long now = System.currentTimeMillis();
            if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) { offAt = now; }
            else if (Intent.ACTION_SCREEN_ON.equals(i.getAction())) {
                int br = cfg().optInt("breakMin", 5);
                if (contStart == 0 || (offAt > 0 && now - offAt >= br * 60000L)) { contStart = now; lastCont = 0; }
                offAt = 0;
            }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        st = getSharedPreferences("st", MODE_PRIVATE);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH_SVC, "Service", NotificationManager.IMPORTANCE_MIN));
        NotificationChannel a = new NotificationChannel(CH_ALERT, "Reminders", NotificationManager.IMPORTANCE_HIGH);
        a.enableVibration(true);
        nm.createNotificationChannel(a);
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(screen, f);
        if (((PowerManager) getSystemService(POWER_SERVICE)).isInteractive()) contStart = System.currentTimeMillis();
    }

    @Override public int onStartCommand(Intent i, int f, int id) {
        Notification n = new NotificationCompat.Builder(this, CH_SVC)
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setContentTitle(ar() ? "وقتك ثمين" : "Your Time Is Precious")
            .setContentText(ar() ? "المتابعة تعمل في الخلفية" : "Monitoring in background")
            .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
        h.removeCallbacks(tick);
        h.post(tick);
        return START_STICKY;
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            try { check(); } catch (Exception e) { }
            h.postDelayed(this, 60000);
        }
    };

    private JSONObject cfg() {
        try { return new JSONObject(getSharedPreferences("cfg", MODE_PRIVATE).getString("cfg", "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }
    private boolean ar() { return !"en".equals(cfg().optString("lang", "ar")); }

    private boolean quiet(JSONObject c) {
        if (c.optInt("quietOn", 1) == 0) return false;
        Calendar n = Calendar.getInstance();
        int m = n.get(Calendar.HOUR_OF_DAY) * 60 + n.get(Calendar.MINUTE);
        String[] s = c.optString("qs", "22:00").split(":"), e = c.optString("qe", "05:00").split(":");
        int a = Integer.parseInt(s[0]) * 60 + Integer.parseInt(s[1]);
        int b = Integer.parseInt(e[0]) * 60 + Integer.parseInt(e[1]);
        return a <= b ? (m >= a && m < b) : (m >= a || m < b);
    }

    private void check() {
        JSONObject c = cfg();
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        if (!today.equals(st.getString("date", ""))) st.edit().putString("date", today).putInt("lastTotal", 0).apply();
        boolean q = quiet(c);

        if (c.optInt("totalOn", 1) == 1 && UsageHelper.hasUsage(this)) {
            int p = Math.max(1, c.optInt("totalMin", 240));
            int m = (int) (UsageHelper.totalSec(this) / 60 / p);
            if (m > st.getInt("lastTotal", 0)) {
                st.edit().putInt("lastTotal", m).apply();
                if (!q) notify(2, m * p, true);
            }
        }
        boolean on = ((PowerManager) getSystemService(POWER_SERVICE)).isInteractive();
        if (c.optInt("contOn", 1) == 1 && on && contStart > 0) {
            int p = Math.max(1, c.optInt("contMin", 120));
            int k = (int) ((System.currentTimeMillis() - contStart) / 60000 / p);
            if (k > lastCont) { lastCont = k; if (!q) notify(3, k * p, false); }
        }
    }

    private String dur(int m) {
        int hh = m / 60, mm = m % 60;
        if (ar()) return (hh > 0 ? hh + " س" : "") + (hh > 0 && mm > 0 ? " و " : "") + (mm > 0 || hh == 0 ? mm + " د" : "");
        return (hh > 0 ? hh + "h " : "") + (mm > 0 || hh == 0 ? mm + "m" : "").trim();
    }

    private void notify(int id, int min, boolean total) {
        String body = total
            ? (ar() ? "مرّت " + dur(min) + " من وقتك على الهاتف 🌿\nتذكّر أن الوقت أمانة، فاجعل منه نصيباً للقرآن والذكر."
                    : dur(min) + " on your phone today 🌿\nYour time is precious. Give some of it to the Quran and dhikr.")
            : (ar() ? "مرّت " + dur(min) + " من الاستخدام المتواصل.\nخذ استراحة من الشاشة."
                    : dur(min) + " of continuous use.\nTake a break from the screen.");
        PendingIntent pi = PendingIntent.getActivity(this, 0,
            getPackageManager().getLaunchIntentForPackage(getPackageName()), PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(ar() ? "وقتك ثمين" : "Your Time Is Precious")
            .setContentText(body.split("\n")[0])
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(pi).setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH);
        if (cfg().optInt("vib", 1) == 1) b.setVibrate(new long[]{0, 200, 100, 200});
        try { getSystemService(NotificationManager.class).notify(id, b.build()); } catch (SecurityException e) { }
    }

    @Override public void onDestroy() { try { unregisterReceiver(screen); } catch (Exception e) { } h.removeCallbacksAndMessages(null); super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }
}
