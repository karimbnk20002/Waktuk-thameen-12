package com.waqtuka.app;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.os.Process;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class UsageHelper {
    public static boolean hasUsage(Context c) {
        AppOpsManager a = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
        int m = a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
        return m == AppOpsManager.MODE_ALLOWED;
    }

    /** مدة استخدام كل تطبيق (بالميلي ثانية) منذ منتصف الليل حتى الآن */
    public static Map<String, Long> today(Context c) {
        Map<String, Long> res = new HashMap<>();
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0);
        long start = cal.getTimeInMillis(), now = System.currentTimeMillis();
        UsageStatsManager u = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
        UsageEvents ev = u.queryEvents(start, now);
        UsageEvents.Event e = new UsageEvents.Event();
        Map<String, Long> open = new HashMap<>();
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e);
            String p = e.getPackageName();
            int type = e.getEventType();
            if (type == UsageEvents.Event.ACTIVITY_RESUMED) {
                open.put(p, e.getTimeStamp());
            } else if (type == UsageEvents.Event.ACTIVITY_PAUSED || type == UsageEvents.Event.ACTIVITY_STOPPED) {
                Long s = open.remove(p);
                if (s != null) res.merge(p, e.getTimeStamp() - s, Long::sum);
            } else if (type == UsageEvents.Event.SCREEN_NON_INTERACTIVE) {
                for (Map.Entry<String, Long> o : open.entrySet())
                    res.merge(o.getKey(), e.getTimeStamp() - o.getValue(), Long::sum);
                open.clear();
            }
        }
        for (Map.Entry<String, Long> o : open.entrySet())
            res.merge(o.getKey(), now - o.getValue(), Long::sum);
        return res;
    }

    public static long totalSec(Context c) {
        long t = 0;
        for (long v : today(c).values()) t += v;
        return t / 1000;
    }
}
