package com.waqtuka.app;

import android.content.*;
import androidx.core.content.ContextCompat;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        if (c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("enabled", false) && UsageHelper.hasUsage(c))
            ContextCompat.startForegroundService(c, new Intent(c, UsageMonitorService.class));
    }
}
