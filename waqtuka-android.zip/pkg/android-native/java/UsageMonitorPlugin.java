package com.waqtuka.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

@CapacitorPlugin(name = "UsageMonitor")
public class UsageMonitorPlugin extends Plugin {

    @PluginMethod public void hasPermission(PluginCall call) {
        JSObject r = new JSObject();
        r.put("usage", UsageHelper.hasUsage(getContext()));
        r.put("notif", Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
        call.resolve(r);
    }

    @PluginMethod public void openUsageSettings(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PluginMethod public void requestNotif(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 33)
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        call.resolve();
    }

    @PluginMethod public void saveConfig(PluginCall call) {
        getContext().getSharedPreferences("cfg", 0).edit().putString("cfg", call.getString("cfg", "{}")).apply();
        call.resolve();
    }

    @PluginMethod public void start(PluginCall call) {
        getContext().getSharedPreferences("cfg", 0).edit().putBoolean("enabled", true).apply();
        ContextCompat.startForegroundService(getContext(), new Intent(getContext(), UsageMonitorService.class));
        call.resolve();
    }

    @PluginMethod public void stop(PluginCall call) {
        getContext().getSharedPreferences("cfg", 0).edit().putBoolean("enabled", false).apply();
        getContext().stopService(new Intent(getContext(), UsageMonitorService.class));
        call.resolve();
    }

    @PluginMethod public void getUsage(PluginCall call) {
        try {
            Map<String, Long> m = UsageHelper.today(getContext());
            long total = 0;
            List<Map.Entry<String, Long>> l = new ArrayList<>(m.entrySet());
            for (Map.Entry<String, Long> e : l) total += e.getValue();
            Collections.sort(l, (a, b) -> Long.compare(b.getValue(), a.getValue()));
            JSONArray top = new JSONArray();
            android.content.pm.PackageManager pm = getContext().getPackageManager();
            for (int i = 0; i < Math.min(5, l.size()); i++) {
                String p = l.get(i).getKey(), name = p;
                try { name = pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString(); } catch (Exception e) { }
                top.put(new JSONObject().put("name", name).put("sec", l.get(i).getValue() / 1000));
            }
            JSObject r = new JSObject();
            r.put("sec", total / 1000);
            r.put("top", top);
            call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
}
