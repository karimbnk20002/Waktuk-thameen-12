import re,sys
p="android/app/src/main/AndroidManifest.xml"
s=open(p,encoding="utf-8").read()
if "xmlns:tools" not in s:
    s=s.replace("<manifest ",'<manifest xmlns:tools="http://schemas.android.com/tools" ',1)
perms='''
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" tools:ignore="ProtectedPermissions"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
'''
comps='''
        <service android:name=".UsageMonitorService" android:exported="false" android:foregroundServiceType="specialUse">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="screen time reminders"/>
        </service>
        <receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter><action android:name="android.intent.action.BOOT_COMPLETED"/></intent-filter>
        </receiver>
'''
s=s.replace("</manifest>",perms+"</manifest>",1)
s=s.replace("</application>",comps+"    </application>",1)
open(p,"w",encoding="utf-8").write(s)
print("manifest patched")
