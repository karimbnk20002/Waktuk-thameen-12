# بناء وقتك ثمين كتطبيق أندرويد (يتابع كل التطبيقات)

المتطلبات: Node.js و Android Studio.

1. أنشئ المشروع:
   npm init -y
   npm i @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "وقتك ثمين" com.waqtuka.app --web-dir www
2. انسخ مجلد www (فيه index.html) إلى مجلد المشروع، ثم:
   npx cap add android
3. انسخ ملفات android-native/java/*.java إلى:
   android/app/src/main/java/com/waqtuka/app/
   (استبدل MainActivity.java الموجود)
4. افتح android/app/src/main/AndroidManifest.xml وأضف المحتوى الموجود في
   android-native/AndroidManifest.additions.xml
5. شغّل: npx cap sync android ثم npx cap open android
   ومن Android Studio اضغط Run على هاتفك (أو Build > Build APK).

عند أول تشغيل: الإعدادات > "متابعة كل التطبيقات" > امنح "الوصول للاستخدام" ثم "الإشعارات".
بعدها تعمل الخدمة في الخلفية وتصلك التنبيهات حتى لو أغلقت التطبيق.

ملاحظات:
- في بعض الهواتف (شاومي، سامسونج، أوبو...) فعّل "تشغيل تلقائي" وأوقف "توفير البطارية" للتطبيق حتى لا يوقف النظام الخدمة.
- جرّب بجعل التذكير "1 د (تجربة)" في الإعدادات.
- نظام iOS لا يسمح بهذه الميزة عملياً دون إذن خاص من Apple.
